/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sistemagestionhotel;

import javax.swing.JOptionPane;

import javax.swing.JOptionPane;

public class Administrador {
    // Clase que maneja el administrador: Habitaciones
    private Habitaciones habitaciones;

    public Administrador(Habitaciones habitaciones) {
        this.habitaciones = habitaciones;
    }
    
    // Menú principal del administrador 
    public void MenuAdministrador() {
        boolean continuar = true;
        while (continuar) {
            try {
                int opcion = Integer.parseInt(JOptionPane.showInputDialog(
                        "Menú de Administrador:\n"
                        + "1. Gestión de reservas\n"
                        + "2. Eliminar/Editar reservas\n"      
                        + "4. Volver al Menú Principal\n"
                        + "Seleccione una opción:"));

                switch (opcion) {
                    case 1:
                        habitaciones.MostrarHabitaciones();
                        break;
                    case 2:
                        habitaciones.ModificarReserva();
                        break;
                    case 3:
                        JOptionPane.showMessageDialog(null, "Regresando al Menú Principal...");
                        continuar = false;
                        break;
                    default:
                        JOptionPane.showMessageDialog(null, "Opción inválida. Intente nuevamente.");
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Ingrese un número válido.");
            }
        }
    }   
    
    // Gestión de habitaciones: ver estado y liberar espacio
    public void gestionHabitaciones() {
        try {
            int opcion = Integer.parseInt(JOptionPane.showInputDialog(
                    "Gestión de Habitaciones:\n"
                    + "1. Ver estado de habitaciones\n"
                    + "2. modificar reserva\n"
                    + "3. Volver"));

            switch (opcion) {
                case 1:
                    habitaciones.MostrarHabitaciones();
                    break;
                case 2:
                    int espacioModificar = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el espacio que desea modificar:"));
                    habitaciones.modificarEspacio(espacioModificar);
                    break;
                case 3:
                    return;
                default:
                    JOptionPane.showMessageDialog(null, "Opción inválida.");
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Ingrese un número válido.");
        }
    }
}
  

