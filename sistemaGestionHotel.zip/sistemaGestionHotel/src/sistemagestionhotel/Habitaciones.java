/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sistemagestionhotel;

import javax.swing.JOptionPane;

public class Habitaciones {
    private String[][] piso3;
    private String[][] piso2;
    private String[][] piso1;
    
   
    public Habitaciones() {
        piso3 = new String[3][3];
        piso2 = new String[3][3];
        piso1 = new String[3][3];
        Pisos();
    }

    // matrix vizualizacion 3x3
    private void Pisos() {
        // piso 1
        piso1[2] = new String[]{"L", "L", "O"};
        piso1[1] = new String[]{"L", "O", "O"};
        piso1[0] = new String[]{"L", "L", "L"};
        
        // piso 2
        piso2[2] = new String[]{"L", "S", "O"};
        piso2[1] = new String[]{"L", "L", "L"};
        piso2[0] = new String[]{"L", "L", "L"};
        
        // piso 3
        piso3[2] = new String[]{"L", "L", "L"};
        piso3[1] = new String[]{"L", "O", "O"};
        piso3[0] = new String[]{"L", "O", "O"};

    }

    public void MostrarHabitaciones() {
        String imprimirPisos = "A continuación se mostrarán los 3 pisos de Habitaciones disponibles\n"
                + "Piso 1:\n" + mostrar(piso1) + "\n"
                + "Piso 2:\n" + mostrar(piso2) + "\n"
                + "Piso 3:\n" + mostrar(piso3);

        JOptionPane.showMessageDialog(null,imprimirPisos);
    }

    private String mostrar(String[][] pisos) {
        String mostrarLosPisos = "";
        for (int i = 0; i < pisos.length; i++) {
            for (int j = 0; j < pisos[i].length; j++) {
                mostrarLosPisos = mostrarLosPisos + "| " + pisos[i][j] + " ";
            }
            mostrarLosPisos = mostrarLosPisos + "|\n";
        }
        return mostrarLosPisos;
    }

    public void ReservarHabitacion() {
        boolean continuar = true;

        while (continuar) {
            JOptionPane.showInputDialog("El costo por noche de la habitacion varia segun el nivel y capacidad de la habitacion: 30$ OCUPACION SENCILLA - 2 50$ OCUPACION DOBLE - 3 50$ OCUPACION SUITE ");
            int piso = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el piso en que desea reservar la habitacion (1-2-3)"));

            // Validar que el piso sea correcto antes de continuar
            if (piso < 1 || piso > 3) {
                JOptionPane.showMessageDialog(null, "Número de piso incorrecto. Intente nuevamente.");
                continue; // Regresa al inicio del while y vuelve a preguntar
            }

            String[][] HabitacionSeleccionado;

            // Seleccionar el nivel correcto
            if (piso == 1) {
                HabitacionSeleccionado = piso1;
            } else if (piso == 2) {
                HabitacionSeleccionado = piso2;
            } else {
                HabitacionSeleccionado = piso3;
            }

            // Mostrar el piso seleccionado antes de pedir la fila y la columna
            String pisoSeleccionado = "Piso " + piso + ":\n" + mostrar(HabitacionSeleccionado);
            JOptionPane.showMessageDialog(null, pisoSeleccionado);

            int fila = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el número de fila en la que desea reservar el espacio")) - 1;
            int columna = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el número de columna en la que desea reservar el espacio")) - 1;
            
            // Verificar si la fila y columna están dentro del rango del nivel seleccionado
            if (fila < 0 || fila >= HabitacionSeleccionado.length || columna < 0 || columna >= HabitacionSeleccionado[0].length) {
                JOptionPane.showMessageDialog(null, "Fila o columna fuera de rango. Intente nuevamente.");
                return;
            }

            String estado = HabitacionSeleccionado[fila][columna];
            if (estado.equals("O")) {
                HabitacionSeleccionado[fila][columna] = "L"; // "L" Libre para reservar el espacio
                JOptionPane.showMessageDialog(null, "Reserva exitosa");
            } else if (estado.equals("O") || estado.equals("S")) { //"O" ocupado, "S" sucia
                JOptionPane.showMessageDialog(null, "No se puede reservar en este espacio");
            } else {
                JOptionPane.showMessageDialog(null, "El espacio seleccionado no está disponible");
            }

            String opcion = JOptionPane.showInputDialog("Seleccione una opción:\n1. Reservar otro espacio\n2. Eliminar una reserva\n3. Salir\nIngrese su opción:");

            if (opcion.equals("1")) {
                // Continuar con la reserva de otro espacio
                continue;
            } else if (opcion.equals("2")) {
                // Llamar a la función para eliminar una reserva
                ModificarReserva();
                // Volver a preguntar después de eliminar la reserva
                continuar = true;  // Volver al ciclo y seguir preguntando
            } else if (opcion.equals("3")) {
                JOptionPane.showMessageDialog(null, "¡Gracias por utilizar el sistema de reservas!");
                continuar = false;  // Terminar el ciclo y salir
            } else {
                JOptionPane.showMessageDialog(null, "Opción no válida. Saliendo...");
                continuar = false;  // Terminar el ciclo si elige una opción no válida
            }
        }
    }

    public void ModificarReserva() {
        int piso = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el piso en que desea modificicar la información de la reserva donde desea eliminar la reserva (1-2-3):"));

        if (piso < 1 || piso > 3) {
            JOptionPane.showMessageDialog(null, "Número de piso incorrecto. Intente nuevamente.");
            return;
        }

        String[][] PisoSeleccionado;

        // Seleccionar el piso correcto
        if (piso == 1) {
            PisoSeleccionado = piso1;
        } else if (piso == 2) {
            PisoSeleccionado = piso2;
        } else {
            PisoSeleccionado = piso3;
        }

        // Mostrar el piso seleccionado antes de pedir la fila y la columna
        String pisoSeleccionado = "piso " + piso + ":\n" + mostrar(PisoSeleccionado);
        JOptionPane.showMessageDialog(null, PisoSeleccionado);

        int fila = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el número de fila del espacio a modificar")) - 1;
        int columna = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el número de columna del espacio a modificar")) - 1;

        // Verificar si la fila y columna están dentro del rango del nivel seleccionado
        if (fila < 0 || fila >= PisoSeleccionado.length || columna < 0 || columna >= PisoSeleccionado[0].length) {
            JOptionPane.showMessageDialog(null, "Fila o columna fuera de rango. Intente nuevamente.");
            return;
        }

        String estado = PisoSeleccionado[fila][columna];
        if (estado.equals("L")) {
            PisoSeleccionado[fila][columna] = "O"; // eliminar la reserva
            JOptionPane.showMessageDialog(null, "Reserva modificada con éxito.");
        } else {
            JOptionPane.showMessageDialog(null, "No hay ninguna reserva en este espacio.");
        }

        // Después de modificar, se vuelve a mostrar el menú
        String opcion = JOptionPane.showInputDialog("Seleccione una opción:\n1. Modificar otro espacio\n2. Modificar una reserva\n3. Salir\nIngrese su opción:");

        if (opcion.equals("1")) {
            // Continuar con la reserva de otro espacio
            MostrarHabitaciones();
        } else if (opcion.equals("2")) {
            // Llamar a la función para eliminar otra reserva
            ModificarReserva();
        } else {
            JOptionPane.showMessageDialog(null, "Opción no válida. Saliendo...");
        }
    }
    
    // Gestión de habitaciones: ver estado y liberar espacio
    public void gestionHabitaciones() {
        try {
            int opcion = Integer.parseInt(JOptionPane.showInputDialog(
                    "Gestión de Habitaciones:\n"
                    + "1. Ver estado de habitaciones\n"
                    + "2. modificar reserva\n"
                    + "3. Volver"));

            switch (opcion) {
                case 1:
                    MostrarHabitaciones();
                    break;
                case 2:
                    int espacioModificar = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el espacio que desea modificar:"));
                    modificarEspacio(espacioModificar);
                    break;
                case 3:
                    return;
                default:
                    JOptionPane.showMessageDialog(null, "Opción inválida.");
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Ingrese un número válido.");
        }
    }

    void modificarEspacio(int espacioModificar) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
