/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package sistemagestionhotel;

import javax.swing.JOptionPane;

public class SistemaGestionHotel {

    private static Object administrador;

    public static void main(String[] args) {
       boolean sistemaActivo = false;
        
        while (!sistemaActivo) {
            try {
                String entrada = JOptionPane.showInputDialog("Bienvenido! ¿Desea ingresar al sistema? (SI = 1 / NO = 0):");
                if (entrada == null) {
                    JOptionPane.showMessageDialog(null, "Saliendo del sistema.");
                    return; // Cerrar programa si el usuario cancela
                }

                int ingresoSistema = Integer.parseInt(entrada);

                if (ingresoSistema == 1) {
                    sistemaActivo = true;
                } else if (ingresoSistema == 0) {
                    JOptionPane.showMessageDialog(null, "Saliendo del sistema.");
                    return; // Salir del programa si el usuario elige 0
                } else {
                    JOptionPane.showMessageDialog(null, "Ingrese una opción válida (1 o 0).");
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Error: Ingrese un número válido.");
            }
        }
        
        boolean continuar = true;

        // Crear instancias de las clases necesarias
        Habitaciones habitaciones = new Habitaciones();
        //Administrador administrador = new Administrador(habitaciones);

        while (continuar) {
            try {
                String opcionStr = JOptionPane.showInputDialog(
                        "Plataforma de Reservación y Administración de Habitaciones:\n"
                                + "1. Registro de Habitaciones.\n"
                                + "2. Detalles de las Reservas.\n"
                                + "3. Gestion de Habitaciones.\n"
                                + "4. Salir.\n"
                                + "Seleccione una opción:");
                
                if (opcionStr == null) {
                    JOptionPane.showMessageDialog(null, "Saliendo del programa.");
                    return; // Cerrar programa si el usuario cancela
                }

                int opcion = Integer.parseInt(opcionStr);

                switch (opcion) {
                    case 1:
                        habitaciones.MostrarHabitaciones();
                        habitaciones.ReservarHabitacion();
                        break;
                    case 2:
                        habitaciones.MostrarHabitaciones();
                        break;
                    case 3:
                        habitaciones.gestionHabitaciones();
                        break;
                    case 4:
                        JOptionPane.showMessageDialog(null, "Saliendo del programa.");
                        continuar = false;
                        break;
                    default:
                        JOptionPane.showMessageDialog(null, "Opción inválida. Intente nuevamente.");
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Error: Ingrese un número válido.");
            }
        }
    }
}
  
